# test_recognition.py - Test script for artwork recognition
import requests
import os

def test_recognition_api():
    """Test the recognition API with sample images"""
    
    api_url = "http://localhost:5000/api/recognize"
    
    # Test with sample images
    test_images = [
        "tests/test_image1.jpg",
        "tests/test_image2.jpg"
    ]
    
    for image_path in test_images:
        if os.path.exists(image_path):
            print(f"Testing with {image_path}...")
            
            with open(image_path, 'rb') as f:
                files = {'image': f}
                response = requests.post(api_url, files=files)
                
                if response.status_code == 200:
                    result = response.json()
                    print(f"✅ Recognition result: {result}")
                else:
                    print(f"❌ API Error: {response.status_code}")
        else:
            print(f"⚠️ Test image not found: {image_path}")

def test_chat_api():
    """Test the chat API"""
    
    api_url = "http://localhost:5000/api/chat"
    
    test_questions = [
        {"question": "Quem pintou o Abaporu?", "language": "pt"},
        {"question": "What is modernism in Brazilian art?", "language": "en"},
        {"question": "¿Cuándo se pintó esta obra?", "language": "es", "artwork_id": 1}
    ]
    
    for test in test_questions:
        print(f"Testing question: {test['question']}")
        
        response = requests.post(api_url, json=test)
        
        if response.status_code == 200:
            result = response.json()
            print(f"✅ Chat response: {result.get('text', 'No text')}")
        else:
            print(f"❌ Chat API Error: {response.status_code}")

if __name__ == "__main__":
    print("🧪 Testing Museum API...")
    print("Make sure the server is running (python museum_app.py)")
    
    test_recognition_api()
    test_chat_api()
